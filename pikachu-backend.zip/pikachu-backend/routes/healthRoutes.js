'use strict';

const express = require('express');

const router = express.Router();

/**
 * GET /health
 * Simple health check endpoint — useful for deployment monitoring.
 */
router.get('/', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

module.exports = router;
