'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');

const router = express.Router();

const AUDIO_DIR = path.join(__dirname, '..', 'audio');

/**
 * GET /audio/:filename
 * Streams a generated WAV audio file to the client.
 * Returns 404 if the file does not exist (e.g. already cleaned up).
 */
router.get('/:filename', (req, res) => {
  const { filename } = req.params;

  // Basic security: no path traversal
  if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
    logger.warn('Path traversal attempt blocked', { filename });
    return res.status(400).json({ success: false, error: 'Invalid filename.' });
  }

  // Only serve .wav files
  if (!filename.toLowerCase().endsWith('.wav')) {
    return res.status(400).json({ success: false, error: 'Only WAV files are served here.' });
  }

  const filePath = path.join(AUDIO_DIR, filename);

  if (!fs.existsSync(filePath)) {
    logger.warn('Audio file not found', { filename });
    return res.status(404).json({ success: false, error: 'Audio file not found or already expired.' });
  }

  logger.debug('Serving audio file', { filename });

  res.setHeader('Content-Type', 'audio/wav');
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

  const stream = fs.createReadStream(filePath);
  stream.on('error', (err) => {
    logger.error('Error streaming audio file', { filename, error: err.message });
    if (!res.headersSent) {
      res.status(500).json({ success: false, error: 'Failed to stream audio file.' });
    }
  });
  stream.pipe(res);
});

module.exports = router;
