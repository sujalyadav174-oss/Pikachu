'use strict';

const express = require('express');
const { uploadAudio } = require('../middleware/upload');
const { handleChat } = require('../controllers/chatController');

const router = express.Router();

/**
 * POST /api/chat
 * Accepts multipart/form-data with field: audio (WAV file)
 * Returns Pikachu's structured JSON response + audio URL
 */
router.post('/chat', uploadAudio, handleChat);

module.exports = router;
