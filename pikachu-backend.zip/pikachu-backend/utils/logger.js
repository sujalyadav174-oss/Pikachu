'use strict';

const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(__dirname, '..', 'logs');

// Ensure logs directory exists
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

function getTimestamp() {
  return new Date().toISOString();
}

function formatMessage(level, message, meta) {
  const base = `[${getTimestamp()}] [${level}] ${message}`;
  if (meta && Object.keys(meta).length > 0) {
    return `${base} ${JSON.stringify(meta)}`;
  }
  return base;
}

function writeToFile(line) {
  const date = new Date().toISOString().slice(0, 10);
  const logFile = path.join(LOG_DIR, `${date}.log`);
  fs.appendFileSync(logFile, line + '\n');
}

const logger = {
  info(message, meta = {}) {
    const line = formatMessage('INFO', message, meta);
    console.log(line);
    writeToFile(line);
  },

  warn(message, meta = {}) {
    const line = formatMessage('WARN', message, meta);
    console.warn(line);
    writeToFile(line);
  },

  error(message, meta = {}) {
    const line = formatMessage('ERROR', message, meta);
    console.error(line);
    writeToFile(line);
  },

  debug(message, meta = {}) {
    if (process.env.NODE_ENV !== 'production') {
      const line = formatMessage('DEBUG', message, meta);
      console.log(line);
      writeToFile(line);
    }
  },
};

module.exports = logger;
