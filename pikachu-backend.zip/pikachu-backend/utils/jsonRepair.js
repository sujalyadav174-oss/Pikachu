'use strict';

/**
 * Attempts to safely parse a JSON string.
 * If parsing fails, tries multiple repair strategies before giving up.
 * Never crashes — always returns a valid object or a safe fallback.
 */

const logger = require('./logger');

const FALLBACK_RESPONSE = {
  reply: "Sorry, I got a little confused there! Can you say that again?",
  emotion: "confused",
  animation: "thinking",
  action: {
    head_tilt: 5,
    look: "center",
    bounce: false,
    blink: true,
  },
};

/**
 * Extracts a JSON object from a string that may contain markdown or extra text.
 */
function extractJson(raw) {
  // Remove markdown code fences
  let cleaned = raw
    .replace(/```json\s*/gi, '')
    .replace(/```\s*/gi, '')
    .trim();

  // Try to find the first complete JSON object
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');

  if (start !== -1 && end !== -1 && end > start) {
    return cleaned.slice(start, end + 1);
  }

  return cleaned;
}

/**
 * Fixes common JSON issues:
 * - Trailing commas
 * - Single quotes instead of double quotes
 * - Unquoted keys
 * - Missing quotes around string values
 */
function repairJson(raw) {
  let str = raw;

  // Replace single quotes with double quotes (simple cases)
  str = str.replace(/'/g, '"');

  // Remove trailing commas before } or ]
  str = str.replace(/,\s*([}\]])/g, '$1');

  // Fix unquoted keys: { key: "value" } -> { "key": "value" }
  str = str.replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g, '$1"$2":');

  return str;
}

/**
 * Validates that the parsed object has the expected Pikachu response shape.
 * Fills in missing fields with safe defaults.
 */
function validateAndFill(obj) {
  const result = { ...FALLBACK_RESPONSE, ...obj };

  // Ensure reply is a non-empty string
  if (typeof result.reply !== 'string' || !result.reply.trim()) {
    result.reply = FALLBACK_RESPONSE.reply;
  }

  // Validate emotion
  const validEmotions = [
    'neutral', 'happy', 'thinking', 'processing', 'listening',
    'speaking', 'sad', 'excited', 'sleepy', 'love', 'angry',
    'surprised', 'confused', 'idle',
  ];
  if (!validEmotions.includes(result.emotion)) {
    result.emotion = 'neutral';
  }

  // Validate animation
  const validAnimations = [
    'idle', 'blink', 'double_blink', 'thinking', 'processing',
    'listening', 'speaking', 'look_left', 'look_right', 'look_up',
    'look_down', 'happy', 'sad', 'love', 'sleep', 'yawn',
    'surprised', 'angry', 'excited', 'nod', 'shake_head', 'bounce',
  ];
  if (!validAnimations.includes(result.animation)) {
    result.animation = 'idle';
  }

  // Validate action object
  if (!result.action || typeof result.action !== 'object') {
    result.action = { ...FALLBACK_RESPONSE.action };
  } else {
    const validLooks = ['left', 'right', 'up', 'down', 'center'];
    result.action = {
      head_tilt: typeof result.action.head_tilt === 'number' ? result.action.head_tilt : 0,
      look: validLooks.includes(result.action.look) ? result.action.look : 'center',
      bounce: typeof result.action.bounce === 'boolean' ? result.action.bounce : false,
      blink: typeof result.action.blink === 'boolean' ? result.action.blink : true,
    };
  }

  return result;
}

/**
 * Main safe parse function.
 * @param {string} raw - Raw string from Gemini
 * @returns {object} - Validated Pikachu response object
 */
function safeParseJson(raw) {
  if (!raw || typeof raw !== 'string') {
    logger.warn('safeParseJson: received empty or non-string input, using fallback');
    return { ...FALLBACK_RESPONSE };
  }

  // Attempt 1: Direct parse
  try {
    const parsed = JSON.parse(raw);
    logger.debug('safeParseJson: direct parse succeeded');
    return validateAndFill(parsed);
  } catch (_) {
    logger.debug('safeParseJson: direct parse failed, attempting extraction');
  }

  // Attempt 2: Extract JSON from surrounding text
  const extracted = extractJson(raw);
  try {
    const parsed = JSON.parse(extracted);
    logger.debug('safeParseJson: extraction parse succeeded');
    return validateAndFill(parsed);
  } catch (_) {
    logger.debug('safeParseJson: extraction parse failed, attempting repair');
  }

  // Attempt 3: Repair then parse
  const repaired = repairJson(extracted);
  try {
    const parsed = JSON.parse(repaired);
    logger.debug('safeParseJson: repair parse succeeded');
    return validateAndFill(parsed);
  } catch (err) {
    logger.error('safeParseJson: all parse attempts failed, using fallback', {
      error: err.message,
      rawSnippet: raw.slice(0, 200),
    });
    return { ...FALLBACK_RESPONSE };
  }
}

module.exports = { safeParseJson, FALLBACK_RESPONSE };
