'use strict';

const fs = require('fs/promises');
const path = require('path');
const logger = require('./logger');

const AUDIO_DELETE_DELAY = parseInt(process.env.AUDIO_DELETE_DELAY, 10) || 300000; // 5 minutes

/**
 * Deletes a file immediately, silently ignoring if it doesn't exist.
 * @param {string} filePath - Absolute path to file
 */
async function deleteFile(filePath) {
  try {
    await fs.unlink(filePath);
    logger.debug('Deleted file', { filePath });
  } catch (err) {
    if (err.code !== 'ENOENT') {
      logger.warn('Could not delete file', { filePath, error: err.message });
    }
  }
}

/**
 * Schedules a file for deletion after AUDIO_DELETE_DELAY milliseconds.
 * Non-blocking — fires and forgets.
 * @param {string} filePath - Absolute path to audio file
 */
function scheduleAudioDeletion(filePath) {
  setTimeout(async () => {
    await deleteFile(filePath);
    logger.info('Scheduled audio file deleted', { filePath });
  }, AUDIO_DELETE_DELAY);

  logger.debug('Audio deletion scheduled', {
    filePath,
    delayMs: AUDIO_DELETE_DELAY,
  });
}

/**
 * Cleans up stale audio files on server startup.
 * Removes any .wav files in the audio directory older than AUDIO_DELETE_DELAY.
 * @param {string} audioDir - Path to audio directory
 */
async function cleanupStaleAudio(audioDir) {
  try {
    const files = await fs.readdir(audioDir);
    const now = Date.now();
    let cleaned = 0;

    for (const file of files) {
      if (!file.endsWith('.wav')) continue;
      const filePath = path.join(audioDir, file);
      try {
        const stat = await fs.stat(filePath);
        const ageMs = now - stat.mtimeMs;
        if (ageMs > AUDIO_DELETE_DELAY) {
          await deleteFile(filePath);
          cleaned++;
        }
      } catch (err) {
        logger.warn('Could not stat file during cleanup', { file, error: err.message });
      }
    }

    if (cleaned > 0) {
      logger.info('Startup audio cleanup complete', { filesRemoved: cleaned });
    }
  } catch (err) {
    // Audio dir may not exist yet — not a fatal error
    if (err.code !== 'ENOENT') {
      logger.warn('Startup audio cleanup error', { error: err.message });
    }
  }
}

module.exports = { deleteFile, scheduleAudioDeletion, cleanupStaleAudio };
