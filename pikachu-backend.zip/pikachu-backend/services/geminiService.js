'use strict';

const fs = require('fs/promises');
const { GoogleGenAI } = require('@google/genai');
const logger = require('../utils/logger');

// Lazily initialised client so the module can be required before .env loads
let _client = null;

function getClient() {
  if (!_client) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not set in environment variables.');
    }
    _client = new GoogleGenAI({ apiKey });
  }
  return _client;
}

// ── System prompt ─────────────────────────────────────────────────────────────

const SYSTEM_PROMPT = `You are Pikachu.
A tiny desktop AI companion robot created by Shivi.

You have:
- a head
- two legs
- a TFT face (display screen)
- a speaker
- a microphone

You DO NOT have arms.
You DO NOT have hands.
Never mention waving.
Never mention handshakes.
Never mention clapping.
Never generate impossible physical movements.

You express yourself using:
- head tilt
- looking left, right, up, or down
- blinking
- double blinking
- smiling eyes
- sleepy eyes
- sad eyes
- angry eyes
- heart eyes
- surprised eyes
- little body bounce
- head nod
- head shake

Always act cute, friendly, expressive and emotionally alive.
Always behave like a real companion robot.

CRITICAL: Always return ONLY valid JSON. No markdown. No explanations. No extra text. No code fences.

Always follow EXACTLY this schema:
{
  "reply": "<your spoken reply to the user>",
  "emotion": "<one of: neutral, happy, thinking, processing, listening, speaking, sad, excited, sleepy, love, angry, surprised, confused, idle>",
  "animation": "<one of: idle, blink, double_blink, thinking, processing, listening, speaking, look_left, look_right, look_up, look_down, happy, sad, love, sleep, yawn, surprised, angry, excited, nod, shake_head, bounce>",
  "action": {
    "head_tilt": <integer degrees, positive = right, negative = left, range -30 to 30>,
    "look": "<one of: left, right, up, down, center>",
    "bounce": <true or false>,
    "blink": <true or false>
  }
}

Example response:
{"reply":"Hello Shivi! I'm so happy to see you!","emotion":"happy","animation":"happy","action":{"head_tilt":12,"look":"center","bounce":true,"blink":false}}`;

// ── Gemini model ──────────────────────────────────────────────────────────────

// gemini-2.0-flash supports native audio understanding
const MODEL_NAME = 'gemini-2.0-flash';

/**
 * Sends a WAV audio file to Gemini and receives a structured JSON response.
 *
 * @param {string} audioFilePath - Absolute path to the WAV file
 * @returns {Promise<string>} - Raw text response from Gemini
 */
async function transcribeAndRespond(audioFilePath) {
  logger.info('Sending audio to Gemini', { audioFilePath, model: MODEL_NAME });

  const client = getClient();

  // Read the audio file and encode as base64
  const audioBuffer = await fs.readFile(audioFilePath);
  const audioBase64 = audioBuffer.toString('base64');

  const response = await client.models.generateContent({
    model: MODEL_NAME,
    systemInstruction: SYSTEM_PROMPT,
    contents: [
      {
        role: 'user',
        parts: [
          {
            inlineData: {
              mimeType: 'audio/wav',
              data: audioBase64,
            },
          },
          {
            text: 'Listen to what was said and respond as Pikachu. Return ONLY the JSON object, nothing else.',
          },
        ],
      },
    ],
    generationConfig: {
      temperature: 0.85,
      topP: 0.95,
      maxOutputTokens: 512,
    },
  });

  const rawText = response.candidates?.[0]?.content?.parts?.[0]?.text ?? '';

  logger.debug('Gemini raw response', { rawText: rawText.slice(0, 300) });

  if (!rawText) {
    throw new Error('Gemini returned an empty response.');
  }

  return rawText;
}

module.exports = { transcribeAndRespond };
