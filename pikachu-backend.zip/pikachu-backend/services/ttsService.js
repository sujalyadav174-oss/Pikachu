'use strict';

const path = require('path');
const fs = require('fs/promises');
const { existsSync, mkdirSync } = require('fs');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

const AUDIO_DIR = path.join(__dirname, '..', 'audio');

// Ensure audio directory exists
if (!existsSync(AUDIO_DIR)) {
  mkdirSync(AUDIO_DIR, { recursive: true });
}

const TTS_VOICE = process.env.TTS_VOICE || 'en-US-AriaNeural';
const TTS_RATE  = process.env.TTS_RATE  || '+0%';
const TTS_PITCH = process.env.TTS_PITCH || '+15Hz';

/**
 * Generates speech from text using Microsoft Edge TTS.
 * Produces a 16-bit PCM WAV file at 16 kHz mono.
 *
 * edge-tts npm package wraps the Edge TTS service and saves to file.
 *
 * @param {string} text - Text to synthesise
 * @returns {Promise<{ filename: string, filePath: string, audioUrl: string }>}
 */
async function generateSpeech(text) {
  if (!text || typeof text !== 'string' || !text.trim()) {
    throw new Error('TTS: text must be a non-empty string.');
  }

  const filename = `${uuidv4()}.wav`;
  const filePath = path.join(AUDIO_DIR, filename);

  logger.info('Generating TTS audio', {
    voice: TTS_VOICE,
    rate: TTS_RATE,
    pitch: TTS_PITCH,
    textLength: text.length,
    outputFile: filename,
  });

  // Dynamically require edge-tts so startup failures surface cleanly
  let EdgeTTS;
  try {
    EdgeTTS = require('edge-tts');
  } catch (err) {
    throw new Error(`edge-tts module not found. Run: npm install edge-tts\nOriginal: ${err.message}`);
  }

  try {
    // edge-tts API: new EdgeTTS.Communicate(text, voice, options)
    // or the functional API depending on version — handle both
    if (typeof EdgeTTS.synthesize === 'function') {
      // Functional API (some versions)
      await EdgeTTS.synthesize({
        text,
        voice: TTS_VOICE,
        rate: TTS_RATE,
        pitch: TTS_PITCH,
        outputFile: filePath,
      });
    } else if (EdgeTTS.Communicate) {
      // Class-based API
      const tts = new EdgeTTS.Communicate(text, TTS_VOICE, {
        rate: TTS_RATE,
        pitch: TTS_PITCH,
      });
      await tts.save(filePath);
    } else {
      // Fallback: try calling the default export as a function
      const communicate = new EdgeTTS(text, TTS_VOICE);
      await communicate.save(filePath);
    }
  } catch (err) {
    // If edge-tts fails for any reason, generate a minimal silent WAV
    // so the ESP32 still gets a valid response (robot shows emotion without audio)
    logger.warn('Edge TTS failed, generating silent WAV fallback', { error: err.message });
    await generateSilentWav(filePath);
  }

  // Verify the file was created
  try {
    await fs.access(filePath);
  } catch {
    logger.warn('TTS file not created, generating silent WAV', { filePath });
    await generateSilentWav(filePath);
  }

  logger.info('TTS audio saved', { filename, filePath });

  return {
    filename,
    filePath,
    audioUrl: `/audio/${filename}`,
  };
}

/**
 * Generates a minimal valid WAV file with 0.1 seconds of silence.
 * Used as fallback when TTS fails.
 *
 * WAV format:
 *   - Sample rate: 16000 Hz
 *   - Bit depth: 16-bit
 *   - Channels: 1 (mono)
 *   - Duration: 0.1 s → 1600 samples → 3200 bytes of PCM data
 *
 * @param {string} filePath
 */
async function generateSilentWav(filePath) {
  const sampleRate = 16000;
  const numChannels = 1;
  const bitsPerSample = 16;
  const durationSeconds = 0.1;
  const numSamples = Math.floor(sampleRate * durationSeconds);
  const dataBytes = numSamples * numChannels * (bitsPerSample / 8);

  // RIFF/WAVE header = 44 bytes
  const buffer = Buffer.alloc(44 + dataBytes, 0);

  // RIFF chunk
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataBytes, 4);
  buffer.write('WAVE', 8);

  // fmt sub-chunk
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);            // sub-chunk size
  buffer.writeUInt16LE(1, 20);             // PCM = 1
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * numChannels * (bitsPerSample / 8), 28); // byte rate
  buffer.writeUInt16LE(numChannels * (bitsPerSample / 8), 32);              // block align
  buffer.writeUInt16LE(bitsPerSample, 34);

  // data sub-chunk
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataBytes, 40);
  // PCM data is already zero (silence)

  await fs.writeFile(filePath, buffer);
  logger.debug('Silent WAV fallback generated', { filePath, dataBytes });
}

module.exports = { generateSpeech };
