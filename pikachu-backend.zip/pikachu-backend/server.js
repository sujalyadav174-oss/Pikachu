'use strict';

// Load environment variables first
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');

const logger = require('./utils/logger');
const { cleanupStaleAudio } = require('./utils/fileCleanup');

const chatRoutes   = require('./routes/chatRoutes');
const audioRoutes  = require('./routes/audioRoutes');
const healthRoutes = require('./routes/healthRoutes');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const app  = express();
const PORT = parseInt(process.env.PORT, 10) || 3000;

// ── Middleware ────────────────────────────────────────────────────────────────

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// Request logger
app.use((req, _res, next) => {
  logger.info(`${req.method} ${req.path}`, { ip: req.ip });
  next();
});

// ── Routes ────────────────────────────────────────────────────────────────────

app.use('/api',     chatRoutes);
app.use('/audio',   audioRoutes);
app.use('/health',  healthRoutes);

// ── Error Handling ────────────────────────────────────────────────────────────

app.use(notFound);
app.use(errorHandler);

// ── Startup ───────────────────────────────────────────────────────────────────

async function start() {
  // Clean up any stale audio files from a previous run
  const audioDir = path.join(__dirname, 'audio');
  await cleanupStaleAudio(audioDir);

  app.listen(PORT, () => {
    logger.info('🤖 Pikachu Robot Backend is running!', {
      port: PORT,
      env: process.env.NODE_ENV || 'development',
      endpoints: {
        chat:   `POST http://localhost:${PORT}/api/chat`,
        audio:  `GET  http://localhost:${PORT}/audio/:filename`,
        health: `GET  http://localhost:${PORT}/health`,
      },
    });
  });
}

// ── Graceful Shutdown ─────────────────────────────────────────────────────────

process.on('SIGTERM', () => {
  logger.info('SIGTERM received — shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('SIGINT received — shutting down gracefully');
  process.exit(0);
});

// Catch unhandled promise rejections (never crash the process)
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection', {
    reason: reason instanceof Error ? reason.message : String(reason),
    stack:  reason instanceof Error ? reason.stack  : undefined,
  });
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception', { error: err.message, stack: err.stack });
  // Give the logger time to flush before exiting
  setTimeout(() => process.exit(1), 500);
});

start();
