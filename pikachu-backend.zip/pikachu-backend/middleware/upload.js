'use strict';

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const MAX_UPLOAD_SIZE = parseInt(process.env.MAX_UPLOAD_SIZE, 10) || 20 * 1024 * 1024; // 20 MB

// Ensure upload directory exists
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination(_req, _file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename(_req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase() || '.wav';
    const filename = `upload_${uuidv4()}${ext}`;
    cb(null, filename);
  },
});

/**
 * Multer file filter — only accept audio/wav or files with .wav extension.
 */
function fileFilter(_req, file, cb) {
  const allowedMimes = ['audio/wav', 'audio/wave', 'audio/x-wav', 'application/octet-stream'];
  const ext = path.extname(file.originalname).toLowerCase();

  if (ext === '.wav' || allowedMimes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    logger.warn('Upload rejected: invalid file type', {
      originalname: file.originalname,
      mimetype: file.mimetype,
    });
    cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'Only WAV audio files are accepted.'));
  }
}

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: MAX_UPLOAD_SIZE,
  },
});

/**
 * Express middleware that wraps multer single-field upload with clean error handling.
 * Field name: 'audio'
 */
function uploadAudio(req, res, next) {
  const handler = upload.single('audio');

  handler(req, res, (err) => {
    if (!err) return next();

    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({
          success: false,
          error: `File too large. Maximum allowed size is ${MAX_UPLOAD_SIZE / (1024 * 1024)} MB.`,
        });
      }
      if (err.code === 'LIMIT_UNEXPECTED_FILE') {
        return res.status(415).json({
          success: false,
          error: err.message || 'Only WAV audio files are accepted.',
        });
      }
      return res.status(400).json({
        success: false,
        error: `Upload error: ${err.message}`,
      });
    }

    // Generic error
    logger.error('Unexpected upload error', { error: err.message });
    return res.status(500).json({
      success: false,
      error: 'Upload failed due to an internal server error.',
    });
  });
}

module.exports = { uploadAudio };
