# 🤖 Pikachu Robot Backend

Backend server for **Pikachu** — a tiny desktop AI companion robot created by **Shivi**.

Pikachu has a head, two legs, a TFT face display, a speaker, and a microphone.
He expresses himself through facial expressions, head tilts, eye movements, body bounces, nods, and shakes.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Runtime | Node.js ≥ 18 |
| Framework | Express.js |
| AI | Google Gemini (`@google/genai`) |
| TTS | Microsoft Edge TTS (`edge-tts`) |
| Upload | Multer |
| Audio | 16-bit PCM WAV @ 16 kHz Mono |
| IDs | UUID v4 |

---

## Project Structure

```
project/
├── server.js               # Entry point
├── package.json
├── .env.example
├── README.md
├── routes/
│   ├── chatRoutes.js       # POST /api/chat
│   ├── audioRoutes.js      # GET /audio/:filename
│   └── healthRoutes.js     # GET /health
├── controllers/
│   └── chatController.js   # Chat workflow orchestration
├── services/
│   ├── geminiService.js    # Google Gemini integration
│   └── ttsService.js       # Edge TTS → WAV generation
├── middleware/
│   ├── upload.js           # Multer WAV upload handler
│   └── errorHandler.js     # Centralized error + 404 handling
├── utils/
│   ├── logger.js           # File + console logger
│   ├── jsonRepair.js       # Safe JSON parser with auto-repair
│   └── fileCleanup.js      # Auto-delete temp files
├── uploads/                # Temp microphone uploads (auto-deleted)
├── audio/                  # Generated TTS WAV files (deleted after 5 min)
└── logs/                   # Daily log files
```

---

## Quick Start

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd pikachu-backend
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
GEMINI_API_KEY=your_actual_gemini_api_key_here
PORT=3000
TTS_VOICE=en-US-AriaNeural
TTS_PITCH=+15Hz
```

### 3. Run

```bash
# Development (auto-restart on file changes)
npm run dev

# Production
npm start
```

Server starts at `http://localhost:3000`

---

## API Reference

### `POST /api/chat`

Upload a WAV audio file from the robot's microphone. Pikachu listens, thinks, and responds.

**Request:**

```
Content-Type: multipart/form-data
Field: audio (WAV file, max 20 MB)
```

**Response:**

```json
{
  "success": true,
  "reply": "Hello Shivi! I'm so happy to see you today!",
  "emotion": "happy",
  "animation": "happy",
  "action": {
    "head_tilt": 12,
    "look": "center",
    "bounce": true,
    "blink": false
  },
  "audio": "/audio/550e8400-e29b-41d4-a716-446655440000.wav"
}
```

---

### `GET /audio/:filename`

Stream a generated WAV speech file.

```
Content-Type: audio/wav
```

Files are automatically deleted after **5 minutes**.

---

### `GET /health`

```json
{ "status": "ok" }
```

---

## Emotion Values

`neutral` `happy` `thinking` `processing` `listening` `speaking`
`sad` `excited` `sleepy` `love` `angry` `surprised` `confused` `idle`

## Animation Values

`idle` `blink` `double_blink` `thinking` `processing` `listening` `speaking`
`look_left` `look_right` `look_up` `look_down` `happy` `sad` `love` `sleep`
`yawn` `surprised` `angry` `excited` `nod` `shake_head` `bounce`

## Action Fields

| Field | Type | Description |
|-------|------|-------------|
| `head_tilt` | integer | Degrees, positive = right, negative = left (-30 to 30) |
| `look` | string | `left` / `right` / `up` / `down` / `center` |
| `bounce` | boolean | Body bounce animation |
| `blink` | boolean | Eye blink |

---

## curl Examples

### Send audio and get Pikachu's response

```bash
curl -X POST http://localhost:3000/api/chat \
  -F "audio=@/path/to/recording.wav" \
  -H "Accept: application/json"
```

### Download the response audio

```bash
# Extract the audio path from the JSON response, then:
curl http://localhost:3000/audio/550e8400-e29b-41d4-a716-446655440000.wav \
  --output pikachu_reply.wav
```

### Health check

```bash
curl http://localhost:3000/health
```

### Full pipeline in one line (requires jq)

```bash
RESPONSE=$(curl -s -X POST http://localhost:3000/api/chat -F "audio=@recording.wav")
echo "Reply: $(echo $RESPONSE | jq -r .reply)"
echo "Emotion: $(echo $RESPONSE | jq -r .emotion)"
AUDIO_PATH=$(echo $RESPONSE | jq -r .audio)
curl -s "http://localhost:3000${AUDIO_PATH}" --output reply.wav
echo "Audio saved to reply.wav"
```

---

## ESP32 HTTP Upload Example (Arduino / ESP-IDF)

```cpp
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ── Config ────────────────────────────────────────────────────────────────────
const char* WIFI_SSID     = "YourWiFiSSID";
const char* WIFI_PASSWORD = "YourWiFiPassword";
const char* SERVER_URL    = "http://192.168.1.100:3000/api/chat";

// ── Recording buffer (adjust to your PSRAM size) ──────────────────────────────
// 16 kHz × 16-bit × 1 ch × 3 seconds = 96000 bytes
#define SAMPLE_RATE     16000
#define RECORD_SECONDS  3
#define BUFFER_SIZE     (SAMPLE_RATE * 2 * RECORD_SECONDS)

uint8_t audioBuffer[BUFFER_SIZE];
size_t  audioBytes = 0;

// ── WAV header builder ────────────────────────────────────────────────────────
void buildWavHeader(uint8_t* header, uint32_t dataBytes) {
  uint32_t byteRate   = SAMPLE_RATE * 1 * 2; // sampleRate * channels * bytesPerSample
  uint16_t blockAlign = 1 * 2;

  // RIFF chunk
  memcpy(header,      "RIFF", 4);
  uint32_t chunkSize = 36 + dataBytes;
  memcpy(header + 4,  &chunkSize, 4);
  memcpy(header + 8,  "WAVE", 4);

  // fmt sub-chunk
  memcpy(header + 12, "fmt ", 4);
  uint32_t subchunk1 = 16;
  memcpy(header + 16, &subchunk1, 4);
  uint16_t audioFmt  = 1; // PCM
  memcpy(header + 20, &audioFmt, 2);
  uint16_t channels  = 1;
  memcpy(header + 22, &channels, 2);
  uint32_t sr        = SAMPLE_RATE;
  memcpy(header + 24, &sr, 4);
  memcpy(header + 28, &byteRate, 4);
  memcpy(header + 32, &blockAlign, 2);
  uint16_t bps       = 16;
  memcpy(header + 34, &bps, 2);

  // data sub-chunk
  memcpy(header + 36, "data", 4);
  memcpy(header + 40, &dataBytes, 4);
}

// ── Upload and parse response ─────────────────────────────────────────────────
void uploadAndProcess() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] Not connected");
    return;
  }

  // Build WAV in memory: 44-byte header + PCM data
  const uint8_t WAV_HEADER_SIZE = 44;
  uint8_t wavHeader[WAV_HEADER_SIZE];
  buildWavHeader(wavHeader, audioBytes);

  // Total WAV size
  size_t wavSize = WAV_HEADER_SIZE + audioBytes;

  // Multipart boundary
  String boundary = "----PikachuBoundary7MA4YWxkTrZu0gW";
  String multipartHeader =
    "--" + boundary + "\r\n"
    "Content-Disposition: form-data; name=\"audio\"; filename=\"recording.wav\"\r\n"
    "Content-Type: audio/wav\r\n\r\n";
  String multipartFooter = "\r\n--" + boundary + "--\r\n";

  size_t totalLength = multipartHeader.length() + wavSize + multipartFooter.length();

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "multipart/form-data; boundary=" + boundary);
  http.addHeader("Content-Length", String(totalLength));

  // Stream body: header + wav header + pcm data + footer
  // Use a custom stream approach
  WiFiClient* stream = http.getStreamPtr();

  // Write multipart header
  stream->print(multipartHeader);

  // Write WAV header
  stream->write(wavHeader, WAV_HEADER_SIZE);

  // Write PCM data in chunks
  const size_t CHUNK = 512;
  size_t sent = 0;
  while (sent < audioBytes) {
    size_t toSend = min(CHUNK, audioBytes - sent);
    stream->write(audioBuffer + sent, toSend);
    sent += toSend;
  }

  // Write multipart footer
  stream->print(multipartFooter);

  int httpCode = http.POST((uint8_t*)nullptr, 0); // trigger send
  // Note: for real ESP32 streaming POST, use WiFiClient directly or esp32-http-update

  if (httpCode == 200) {
    String payload = http.getString();
    Serial.println("[HTTP] Response: " + payload);

    // Parse JSON
    StaticJsonDocument<1024> doc;
    DeserializationError err = deserializeJson(doc, payload);

    if (!err) {
      const char* reply     = doc["reply"];
      const char* emotion   = doc["emotion"];
      const char* animation = doc["animation"];
      const char* audioPath = doc["audio"];

      int   headTilt = doc["action"]["head_tilt"] | 0;
      const char* look   = doc["action"]["look"] | "center";
      bool  bounce   = doc["action"]["bounce"] | false;
      bool  blink    = doc["action"]["blink"]  | true;

      Serial.printf("[Pikachu] Reply: %s\n",     reply     ? reply     : "");
      Serial.printf("[Pikachu] Emotion: %s\n",   emotion   ? emotion   : "");
      Serial.printf("[Pikachu] Animation: %s\n", animation ? animation : "");
      Serial.printf("[Pikachu] Head tilt: %d\n", headTilt);
      Serial.printf("[Pikachu] Look: %s\n",      look);
      Serial.printf("[Pikachu] Bounce: %s\n",    bounce ? "yes" : "no");
      Serial.printf("[Pikachu] Blink: %s\n",     blink  ? "yes" : "no");

      // ── Apply to robot hardware ──────────────────────────────────────────
      // applyEmotion(emotion);
      // applyAnimation(animation);
      // applyHeadTilt(headTilt);
      // applyLookDirection(look);
      // if (bounce) triggerBounce();
      // if (blink)  triggerBlink();

      // ── Download and play audio ──────────────────────────────────────────
      if (audioPath) {
        String audioUrl = String("http://192.168.1.100:3000") + audioPath;
        // downloadAndPlayWav(audioUrl);
        Serial.println("[Audio] URL: " + audioUrl);
      }
    } else {
      Serial.println("[JSON] Parse error: " + String(err.c_str()));
    }
  } else {
    Serial.printf("[HTTP] Error: %d\n", httpCode);
  }

  http.end();
}

// ── Arduino setup / loop ──────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("[WiFi] Connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n[WiFi] Connected: " + WiFi.localIP().toString());

  // Fill buffer with test silence for demonstration
  // In real usage: record from I2S microphone into audioBuffer
  memset(audioBuffer, 0, sizeof(audioBuffer));
  audioBytes = BUFFER_SIZE;

  uploadAndProcess();
}

void loop() {
  // Record and upload when button is pressed or wake word detected
  delay(10000);
}
```

---

## Deployment

### Railway (Recommended for always-on)

1. Push code to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add environment variables in the Railway dashboard:
   ```
   GEMINI_API_KEY=your_key
   PORT=3000
   NODE_ENV=production
   TTS_VOICE=en-US-AriaNeural
   TTS_PITCH=+15Hz
   ```
4. Railway auto-detects Node.js and runs `npm start`
5. Your public URL will be something like `https://pikachu-backend.up.railway.app`

**Note:** Railway has persistent filesystem — uploads and audio folders work correctly.

---

### Vercel (Serverless — limited)

> ⚠️ Vercel uses serverless functions with a **read-only filesystem** and **10s timeout**.
> Audio file serving won't persist between invocations.
> Use Railway or a VPS for production. Vercel is fine for testing.

1. Install Vercel CLI: `npm i -g vercel`
2. Create `vercel.json` in project root:

```json
{
  "version": 2,
  "builds": [{ "src": "server.js", "use": "@vercel/node" }],
  "routes": [{ "src": "/(.*)", "dest": "/server.js" }]
}
```

3. Deploy:

```bash
vercel --prod
```

4. Set environment variables in Vercel dashboard → Settings → Environment Variables.

**For production use on Vercel**, replace local audio file serving with an object storage service (AWS S3, Cloudflare R2, Supabase Storage) and generate pre-signed URLs.

---

### Self-hosted VPS (Ubuntu)

```bash
# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone and set up
git clone <repo-url> /opt/pikachu-backend
cd /opt/pikachu-backend
npm install --production
cp .env.example .env
nano .env  # add your GEMINI_API_KEY

# Install PM2 process manager
npm install -g pm2
pm2 start server.js --name pikachu-backend
pm2 save
pm2 startup
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `GEMINI_API_KEY` | *(required)* | Google Gemini API key |
| `PORT` | `3000` | Server port |
| `NODE_ENV` | `development` | `development` or `production` |
| `MAX_UPLOAD_SIZE` | `20971520` | Max WAV upload in bytes (20 MB) |
| `AUDIO_DELETE_DELAY` | `300000` | Audio file TTL in ms (5 min) |
| `TTS_VOICE` | `en-US-AriaNeural` | Edge TTS voice |
| `TTS_RATE` | `+0%` | TTS speech rate |
| `TTS_PITCH` | `+15Hz` | TTS pitch adjustment |

---

## Error Responses

| Status | Meaning |
|--------|---------|
| `400` | No file uploaded / invalid filename |
| `413` | File exceeds 20 MB limit |
| `415` | Not a WAV file |
| `502` | Gemini API failure |
| `500` | Unexpected server error |

---

## About Pikachu

Pikachu is a small desktop AI companion robot created by **Shivi**.

He has a head, two legs, a TFT face, a speaker, and a microphone.
He has **no arms** and **no hands**.

He expresses himself through his TFT face display (eyes and expressions), head tilt, head nod, head shake, body bounce, and blinking — making him feel truly alive and emotional.

---

*Made with ❤️ for Pikachu by Shivi*
